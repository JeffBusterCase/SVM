# SVM
Compile paths with ruby code.

<h5> Very simple </h5>
in terminal '#/SVM/' 
write 
--
<code>secur</code>
  for folder
--
<code>securfolder</code>
  for a entire folder
  
  
Using secure folder you need a file in the folder with the same name as the folder, and in the first line of the file put '#<folder: folderName>'<br>
Example: at 'example/example.rb' first line
<code>"<br>
  #\<folder: example\>
<br>"</code>

